package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class CookBook_Write_Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.cookbook_write)
    }
}