package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Write_Community_Notice_Cook_Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.write_community_notice_cook)
    }
}